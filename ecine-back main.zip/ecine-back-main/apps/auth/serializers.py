from datetime import datetime
from django.contrib.auth.hashers import make_password
from apps.users.models import Rol, Cliente
from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from django.core.validators import RegexValidator

class RegisterSerializer(serializers.ModelSerializer):
    Password = serializers.CharField(write_only=True)
    Nombre = serializers.CharField(max_length=100)
    Apellido_Mat = serializers.CharField(max_length=100)
    Apellido_Pat = serializers.CharField(max_length=100)

    email_validator = RegexValidator(
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
        'Correo electrónico no válido. Asegúrese de que sea un correo válido.'
    )

    Correo = serializers.CharField(
        max_length=100,
        validators=[
            UniqueValidator(queryset=Cliente.objects.all(), message="Este correo ya está registrado."),
            email_validator
        ]
    )

    class Meta:
        model = Cliente
        fields = ['Nombre', 'Apellido_Mat', 'Apellido_Pat', 'Correo', 'Password']

    def create(self, validated_data):
        rol = Rol.objects.get(id=1)
        Password = validated_data.pop('Password')
        hashed_password = make_password(Password)
        cliente = Cliente.objects.create(
            Nombre=validated_data['Nombre'],
            Apellido_Mat=validated_data['Apellido_Mat'],
            Apellido_Pat=validated_data['Apellido_Pat'],
            Fecha_Ingreso=datetime.now().strftime('%Y-%m-%d'),
            Correo=validated_data['Correo'],
            Password=hashed_password,
            rol=rol
        )

        cliente.save()

        return cliente
