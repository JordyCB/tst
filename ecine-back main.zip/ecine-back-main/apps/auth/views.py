from datetime import datetime

from django.contrib.auth.hashers import check_password
from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from rest_framework.exceptions import AuthenticationFailed

from ECINE.utils import get_timestamp
from apps.auth.serializers import RegisterSerializer
from apps.users.models import Cliente


class RegisterViewSet(viewsets.ViewSet):
    permission_classes = [AllowAny]

    def create(self, request):
        serializer = RegisterSerializer(data=request.data)

        if serializer.is_valid():
            user = serializer.save()

            # Generar token
            refresh = RefreshToken.for_user(user)
            refresh["id"] = user.id
            refresh["correo"] = user.Correo
            refresh["Apellido_Mat"] = user.Apellido_Mat
            refresh["Apellido_Pat"] = user.Apellido_Pat
            refresh["Nombre"] = user.Nombre
            refresh["rol_id"] = user.rol.id
            access_token = str(refresh.access_token)

            return Response({
                'status': 201,
                'message': 'Cliente registrado exitosamente.',
                'detail': 'El cliente ha sido registrado correctamente en el sistema y puede acceder a su cuenta con las credenciales proporcionadas.',
                'access': access_token,
                'timestamp': get_timestamp()
            }, status=status.HTTP_201_CREATED)

        return Response({
            'status': 400,
            'message': 'Error al registrar el cliente.',
            'detail': serializer.errors,
            'timestamp': get_timestamp()
        }, status=status.HTTP_400_BAD_REQUEST)





class LoginViewSet(viewsets.ViewSet):
    permission_classes = [AllowAny]

    def create(self, request):
        correo = request.data.get('Correo')
        password = request.data.get('Password')

        # Validación de datos de entrada
        validation_error = self.validate_fields(correo, password)
        if validation_error:
            return validation_error

        user = self.authenticate(correo, password)
        if user is None:
            return Response({
                "status": 400,
                "message": "Error al iniciar sesión.",
                "detail": "Correo o contraseña no válidos.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_400_BAD_REQUEST)

        refresh = RefreshToken.for_user(user)
        refresh["id"] = user.id
        refresh["correo"] = user.Correo
        refresh["Apellido_Mat"] = user.Apellido_Mat
        refresh["Apellido_Pat"] = user.Apellido_Pat
        refresh["Nombre"] = user.Nombre
        refresh["rol_id"] = user.rol.id
        access_token = str(refresh.access_token)

        return Response({
            "status": 200,
            "message": "Inicio de sesión exitoso.",
            "detail": "Token de acceso generado correctamente.",
            "access": access_token,
            "timestamp": get_timestamp()
        })

    def authenticate(self, correo, password):
        try:
            user = Cliente.objects.get(Correo=correo)
            if check_password(password, user.Password):
                return user
            return None
        except Cliente.DoesNotExist:
            return None

    def validate_fields(self, correo, password):
        if not correo:
            return Response({
                "status": 400,
                "message": "Error al iniciar sesión.",
                "detail": {
                    "Correo": ["Correo electrónico es requerido."]
                },
                "timestamp": get_timestamp()
            }, status=status.HTTP_400_BAD_REQUEST)

        if not password:
            return Response({
                "status": 400,
                "message": "Error al iniciar sesión.",
                "detail": {
                    "password": ["Contraseña es requerida."]
                },
                "timestamp": get_timestamp()
            }, status=status.HTTP_400_BAD_REQUEST)
        return None
