from django.contrib.auth.hashers import make_password
from django.db import models

class Cliente(models.Model):
    id = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=100)
    Apellido_Mat = models.CharField(max_length=100)
    Apellido_Pat = models.CharField(max_length=100)
    Fecha_Ingreso = models.DateField()
    Correo = models.EmailField(unique=True)
    Password = models.CharField(max_length=100)
    rol = models.ForeignKey('Rol', on_delete=models.CASCADE)

    def set_password(self, Password):
        self.Password = make_password(Password)


class Rol(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=25, unique=True)
