from rest_framework import viewsets, status
from rest_framework.response import Response

from ECINE.utils import get_timestamp
from .models import *
from .serializers import *


class PeliculaViewSet(viewsets.ViewSet):

    def create(self, request):
        serializer = PeliculaSerializer(data=request.data)
        if serializer.is_valid():
            pelicula = serializer.save()
            return Response({
                "status": 201,
                "message": "Película registrada exitosamente.",
                "detail": f"La película '{pelicula.titulo}' ha sido guardada correctamente.",
                "data": serializer.data,
                "timestamp": get_timestamp()
            }, status=status.HTTP_201_CREATED)

        return Response({
            "status": 400,
            "message": "Error al registrar la película.",
            "detail": serializer.errors,
            "timestamp": get_timestamp()
        }, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request):
        peliculas = Pelicula.objects.all()
        serializer = PeliculaSerializer(peliculas, many=True)
        return Response({
            "status": 200,
            "message": "Películas obtenidas correctamente.",
            "data": serializer.data,
            "timestamp": get_timestamp()
        }, status=status.HTTP_200_OK)


class HorarioViewSet(viewsets.ViewSet):
    def list(self, request):
        queryset = Horario.objects.all()
        serializer = HorarioSerializer(queryset, many=True)
        return Response({
            'status': 200,
            'message': 'Lista de horarios obtenida correctamente.',
            'detail': serializer.data,
            'timestamp': get_timestamp()
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            horario = Horario.objects.get(pk=pk)
            serializer = HorarioSerializer(horario)
            return Response({
                'status': 200,
                'message': 'Detalle del horario obtenido correctamente.',
                'detail': serializer.data,
                'timestamp': get_timestamp()
            }, status=status.HTTP_200_OK)
        except Horario.DoesNotExist:
            return Response({
                'status': 404,
                'message': 'Horario no encontrado.',
                'detail': f"No existe un horario con ID {pk}.",
                'timestamp': get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)

    def create(self, request):
        serializer = HorarioSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                'status': 201,
                'message': 'Horario creado correctamente.',
                'detail': serializer.data,
                'timestamp': get_timestamp()
            }, status=status.HTTP_201_CREATED)
        return Response({
            'status': 400,
            'message': 'Error al crear el horario.',
            'detail': serializer.errors,
            'timestamp': get_timestamp()
        }, status=status.HTTP_400_BAD_REQUEST)


class SucursalViewSet(viewsets.ViewSet):

    def list(self, request):
        sucursales = Sucursal.objects.all()
        serializer = SucursalSerializer(sucursales, many=True)
        return Response({
            "status": 200,
            "message": "Listado de sucursales obtenido correctamente.",
            "detail": serializer.data,
            "timestamp": get_timestamp()
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            sucursal = Sucursal.objects.get(pk=pk)
            serializer = SucursalSerializer(sucursal)
            return Response({
                "status": 200,
                "message": "Sucursal obtenida correctamente.",
                "detail": serializer.data,
                "timestamp": get_timestamp()
            }, status=status.HTTP_200_OK)
        except Sucursal.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sucursal no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)

    def create(self, request):
        serializer = SucursalSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": 201,
                "message": "Sucursal creada exitosamente.",
                "detail": serializer.data,
                "timestamp": get_timestamp()
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": 400,
            "message": "Error al crear la sucursal.",
            "detail": serializer.errors,
            "timestamp": get_timestamp()
        }, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        try:
            sucursal = Sucursal.objects.get(pk=pk)
            serializer = SucursalSerializer(sucursal, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({
                    "status": 200,
                    "message": "Sucursal actualizada correctamente.",
                    "detail": serializer.data,
                    "timestamp": get_timestamp()
                }, status=status.HTTP_200_OK)
            return Response({
                "status": 400,
                "message": "Error al actualizar la sucursal.",
                "detail": serializer.errors,
                "timestamp": get_timestamp()
            }, status=status.HTTP_400_BAD_REQUEST)
        except Sucursal.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sucursal no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            sucursal = Sucursal.objects.get(pk=pk)
            sucursal.delete()
            return Response({
                "status": 200,
                "message": "Sucursal eliminada correctamente.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_200_OK)
        except Sucursal.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sucursal no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)


class SalaViewSet(viewsets.ViewSet):

    def list(self, request):
        salas = Sala.objects.all()
        serializer = SalaSerializer(salas, many=True)
        return Response({
            "status": 200,
            "message": "Salas obtenidas correctamente.",
            "detail": serializer.data,
            "timestamp": get_timestamp()
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, pk=None):
        try:
            sala = Sala.objects.get(pk=pk)
            serializer = SalaSerializer(sala)
            return Response({
                "status": 200,
                "message": "Sala obtenida correctamente.",
                "detail": serializer.data,
                "timestamp": get_timestamp()
            }, status=status.HTTP_200_OK)
        except Sala.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sala no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)

    def create(self, request):
        serializer = SalaSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": 201,
                "message": "Sala creada exitosamente.",
                "detail": serializer.data,
                "timestamp": get_timestamp()
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": 400,
            "message": "Error al crear la sala.",
            "detail": serializer.errors,
            "timestamp": get_timestamp()
        }, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        try:
            sala = Sala.objects.get(pk=pk)
            serializer = SalaSerializer(sala, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({
                    "status": 200,
                    "message": "Sala actualizada correctamente.",
                    "detail": serializer.data,
                    "timestamp": get_timestamp()
                }, status=status.HTTP_200_OK)
            return Response({
                "status": 400,
                "message": "Error al actualizar la sala.",
                "detail": serializer.errors,
                "timestamp": get_timestamp()
            }, status=status.HTTP_400_BAD_REQUEST)
        except Sala.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sala no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            sala = Sala.objects.get(pk=pk)
            sala.delete()
            return Response({
                "status": 200,
                "message": "Sala eliminada correctamente.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_200_OK)
        except Sala.DoesNotExist:
            return Response({
                "status": 404,
                "message": "Sala no encontrada.",
                "timestamp": get_timestamp()
            }, status=status.HTTP_404_NOT_FOUND)
