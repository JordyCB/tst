from rest_framework import serializers
from .models import *


class PeliculaSerializer(serializers.ModelSerializer):
    imagen = serializers.ImageField(use_url=True)
    idioma_nombre = serializers.CharField(source='idioma.idioma', read_only=True)
    clasificacion_nombre = serializers.CharField(source='clasificacion.clasificacion', read_only=True)
    class Meta:
        model = Pelicula
        fields = '__all__'

class HorarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Horario
        fields = '__all__'

class SucursalSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sucursal
        fields = '__all__'

class SalaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sala
        fields = '__all__'