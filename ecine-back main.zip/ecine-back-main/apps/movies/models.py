from django.db import models

class Clasificacion(models.Model):
    id = models.AutoField(primary_key=True)
    clasificacion = models.CharField(max_length=10)
    descripcion = models.TextField()

    def __str__(self):
        return self.clasificacion

class Idioma(models.Model):
    id = models.AutoField(primary_key=True)
    idioma = models.CharField(max_length=50)

    def __str__(self):
        return self.idioma

class Pelicula(models.Model):
    id = models.AutoField(primary_key=True)
    titulo = models.CharField(max_length=255)
    sinopsis = models.TextField()
    año = models.CharField(max_length=4)
    idioma = models.ForeignKey(Idioma, on_delete=models.CASCADE)
    duracion = models.CharField(max_length=10)
    clasificacion = models.ForeignKey(Clasificacion, on_delete=models.CASCADE)
    imagen = models.ImageField(upload_to="peliculas/", null=True, blank=True)

    def __str__(self):
        return self.titulo

class Sucursal(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Sala(models.Model):
    id = models.AutoField(primary_key=True)
    nombre_sala = models.CharField(max_length=50)
    tipo = models.CharField(max_length=50)
    capacidad = models.IntegerField()
    sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nombre_sala} ({self.sucursal.nombre})"

class Horario(models.Model):
    id = models.AutoField(primary_key=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    hora = models.TimeField()
    pelicula = models.ForeignKey(Pelicula, on_delete=models.CASCADE)
    sala = models.ForeignKey(Sala, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.pelicula.titulo} - {self.hora} - {self.sala.nombre_sala}"
