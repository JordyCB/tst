from django.urls import path
from .views import (
    PeliculaViewSet,
    HorarioViewSet,
    SucursalViewSet,
    SalaViewSet,
)

# Películas
pelicula_create = PeliculaViewSet.as_view({'post': 'create'})
pelicula_list = PeliculaViewSet.as_view({'get': 'list'})

# Horarios
horario_create = HorarioViewSet.as_view({'post': 'create'})
horario_list = HorarioViewSet.as_view({'get': 'list'})
horario_detail = HorarioViewSet.as_view({'get': 'retrieve'})

# Sucursales
sucursal_create = SucursalViewSet.as_view({'post': 'create'})
sucursal_list = SucursalViewSet.as_view({'get': 'list'})
sucursal_detail = SucursalViewSet.as_view({'get': 'retrieve'})
sucursal_update = SucursalViewSet.as_view({'patch': 'partial_update'})
sucursal_delete = SucursalViewSet.as_view({'delete': 'destroy'})

# Salas
sala_create = SalaViewSet.as_view({'post': 'create'})
sala_list = SalaViewSet.as_view({'get': 'list'})
sala_detail = SalaViewSet.as_view({'get': 'retrieve'})
sala_update = SalaViewSet.as_view({'patch': 'partial_update'})
sala_delete = SalaViewSet.as_view({'delete': 'destroy'})

urlpatterns = [
    # Películas
    path('peliculas/', pelicula_list, name='pelicula-list'),
    path('peliculas/crear/', pelicula_create, name='pelicula-create'),

    # Horarios
    path('horarios/', horario_list, name='horario-list'),
    path('horarios/crear/', horario_create, name='horario-create'),
    path('horarios/<int:pk>/', horario_detail, name='horario-detail'),

    # Sucursales
    path('sucursales/', sucursal_list, name='sucursal-list'),
    path('sucursales/crear/', sucursal_create, name='sucursal-create'),
    path('sucursales/<int:pk>/', sucursal_detail, name='sucursal-detail'),
    path('sucursales/<int:pk>/editar/', sucursal_update, name='sucursal-update'),
    path('sucursales/<int:pk>/eliminar/', sucursal_delete, name='sucursal-delete'),

    # Salas
    path('salas/', sala_list, name='sala-list'),
    path('salas/crear/', sala_create, name='sala-create'),
    path('salas/<int:pk>/', sala_detail, name='sala-detail'),
    path('salas/<int:pk>/editar/', sala_update, name='sala-update'),
    path('salas/<int:pk>/eliminar/', sala_delete, name='sala-delete'),
]
