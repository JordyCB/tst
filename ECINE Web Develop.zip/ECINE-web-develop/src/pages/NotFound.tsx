const NotFound = () => {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>404 - Página no encontrada</h1>
    </div>
  );
};

export default NotFound;
