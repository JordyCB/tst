declare module 'react-star-ratings';
